import java.util.Scanner;

public class Arraymanipulation1 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Get the number of elements in the array from the user
        System.out.print("Enter the number of integers: ");
        int n = scanner.nextInt();

        // Create an array to store the integers
        int[] array = new int[n];

        // Get integer inputs from the user and store them in the array
        for (int i = 0; i < n; i++) {
            System.out.print("Enter integer #" + (i + 1) + ": ");
            array[i] = scanner.nextInt();
        }

        // Display the array
        System.out.print("Array: ");
        for (int num : array) {
            System.out.print(num + " ");
        }
        System.out.println(); // Print a new line after displaying the array

        // Calculate and display the sum of all integers
        int sum = 0;
        for (int num : array) {
            sum += num;
        }
        System.out.println("Sum of all integers: " + sum);

        // Find and display the highest and lowest number in the array
        int max = array[0];
        int min = array[0];
        for (int num : array) {
            if (num > max) {
                max = num;
            }
            if (num < min) {
                min = num;
            }
        }
        System.out.println("Highest number: " + max);
        System.out.println("Lowest number: " + min);

        // Close the scanner
        scanner.close();
    }
}
