import java.util.Scanner;

public class StringManupulation {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Input from user
        System.out.print("Enter a string: ");
        String input = scanner.nextLine();

        // Count and display the number of vowels
        int vowelCount = countVowels(input);
        System.out.println("Number of vowels: " + vowelCount);

        //c
        String reversed = reverseString(input);
        System.out.println("Reversed string: " + reversed);

        // Convert the string to uppercase and display
        String uppercase = input.toUpperCase();
        System.out.println("Uppercase string: " + uppercase);

        scanner.close();
    }

    // Function to count vowels in a string
    public static int countVowels(String str) {
        int count = 0;
        str = str.toLowerCase(); // Convert the string to lowercase for case-insensitive matching

        for (int i = 0; i < str.length(); i++) {
            char ch = str.charAt(i);
            if (ch == 'a' || ch == 'e' || ch == 'i' || ch == 'o' || ch == 'u') {
                count++;
            }
        }

        return count;
    }

    // Function to reverse a string
    public static String reverseString(String str) {
        StringBuilder reversed = new StringBuilder();
        for (int i = str.length() - 1; i >= 0; i--) {
            reversed.append(str.charAt(i));
        }
        return reversed.toString();
    }
}
